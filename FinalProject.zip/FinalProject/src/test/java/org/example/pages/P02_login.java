package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;
import static org.example.stepDefs.Hooks.driver;

public class P02_login {


    public WebElement LoginClick(){
        return driver.findElement(By.cssSelector("a[class=\"ico-login\"]"));
    }
    public WebElement ValidEmail(){

            return driver.findElement(By.className("email"));

    }
    public WebElement ValidPassword(){
        return driver.findElement(By.name("Password"));
    }
    public WebElement Loginbutton() {
        return driver.findElement(By.className("login-button"));
    }


    public WebElement InvalidEmail(){
        return driver.findElement(By.className("email"));
    }
    public WebElement InvalidPassword(){
        return driver.findElement(By.name("Password"));


    }

}

package org.example.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.Collections;
import java.util.List;

import static org.example.stepDefs.Hooks.driver;
public class P03_homePage {

    public WebElement Currency(){
        return driver.findElement(By.id("customerCurrency"));
    }

    public List<WebElement> PriceList() {
        return Collections.singletonList(driver.findElement(By.cssSelector("span[class=\"price actual-price\"]")));
    }



    //Search
    public WebElement Searchicon(){
        return driver.findElement(By.id("small-searchterms"));

    }
    public WebElement SearchClick(){
        return driver.findElement(By.cssSelector("button[class=\"button-1 search-box-button\"]"));
    }
    public List<WebElement> SearchResult(){
        return Collections.singletonList(driver.findElement(By.cssSelector("h2[class=\"product-title\"]")));
    }

    public WebElement Product1(){
        return driver.findElement(By.cssSelector("div[class=\"picture\"]"));

    }
    public WebElement Product2(){
        return driver.findElement(By.cssSelector("div[class=\"picture\"]"));

    }
    public WebElement Product3(){
        return  driver.findElement(By.cssSelector("div[class=\"picture\"]"));
    }

    //Hover
    public WebElement Computers(){
        return driver.findElement(By.cssSelector("a[href=\"/computers\"]"));
    }
    public WebElement Electronics(){
        return driver.findElement(By.cssSelector("a[href=\"/electronics\"]"));
    }
    public WebElement Apparel(){
        return driver.findElement(By.cssSelector("a[href=\"/apparel\"]"));
    }

    public WebElement Destop(){
        return driver.findElement(By.xpath("/html/body/div[6]/div[2]/ul[1]/li[1]/ul/li[1]/a"));
    }
public WebElement Notebooks(){
        return driver.findElement(By.xpath("/html/body/div[6]/div[2]/ul[1]/li[1]/ul/li[2]/a"));
}
public WebElement Software(){
        return driver.findElement(By.xpath( "/html/body/div[6]/div[2]/ul[1]/li[1]/ul/li[3]/a"));
}

    public WebElement PageTitle(){
        return driver.findElement(By.cssSelector("a[href=\"/desktops\"]"));
    }

    //HomeSlide

    public List<WebElement> SlideClick(){
        return Collections.singletonList(driver.findElement(By.cssSelector("div[class=\"nivo-controlNav\"]")));


    }
    public List<WebElement> Slider(){
        return Collections.singletonList(driver.findElement(By.id("id=\"nivo-slider\"")));
    }

    //Follow Us
    //public List<WebElement>SocialIcons(){
       //return Collections.singletonList(driver.findElement(By.cssSelector("ul[class=\"networks\"]>li>a")));

    public WebElement FacebookIcon(){
        return driver.findElement(By.cssSelector("li[class=\"facebook\"]"));
    }
    public WebElement TwitterIcon(){
        return driver.findElement(By.cssSelector("li[class=\"twitter\"]"));
    }
    public WebElement RSSIcon(){
        return driver.findElement(By.cssSelector("li[class=\"rss\"]"));
    }
    public WebElement YoutubeIcon(){
        return driver.findElement(By.cssSelector("li[class=\"youtube\"]"));
    }

//WishList
   public List<WebElement> SelectProduct(){
        return driver.findElements(By.cssSelector("h2[class=\"product-title\"]"));
    }
    public WebElement AddWishList(){
        return driver.findElement(By.id("add-to-wishlist-button-18"));
    }
    public WebElement SuccessMsg(){
        return driver.findElement(By.cssSelector("div[class=\"bar-notification success\"]"));
    }

public WebElement WishListQunantity(){
        return driver.findElement(By.cssSelector("input[class=\"qty-input\"]"));
}
    public WebElement WishListButton(){
        return driver.findElement(By.cssSelector("span[class=\"wishlist-label\"]"));}

}








package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import static org.example.stepDefs.Hooks.driver;
public class P01_register {
public WebElement Registerpage(){
    return driver.findElement(By.className("ico-register"));
}
public WebElement Gender(){
    return driver.findElement(By.id("gender-female"));
}
public WebElement firstname(){
    return driver.findElement(By.id("FirstName"));
}
public WebElement Lastname(){
        return driver.findElement(By.id("LastName"));
    }
 public WebElement Year(){
        return driver.findElement(By.cssSelector("select[name=\"DateOfBirthYear\"]"));
    }
 public WebElement Month(){
        return driver.findElement(By.cssSelector("select[name=\"DateOfBirthMonth\"]"));
    }
 public WebElement Day(){
        return driver.findElement(By.cssSelector("select[name=\"DateOfBirthDay\"]"));
    }
 public WebElement Email(){
    return driver.findElement(By.id("Email"));
 }
public WebElement Company(){
    return driver.findElement(By.id("Company"));
}
public WebElement Password(){
    return driver.findElement(By.name("Password"));

}
public WebElement ConfirmPassword(){
return driver.findElement(By.name("ConfirmPassword"));
    }
public WebElement RegisterButton(){
    return driver.findElement(By.cssSelector("button[class=\"button-1 register-next-step-button\"]"));
}


}

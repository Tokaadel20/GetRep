package org.example.stepDefs;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P02_login;
import org.openqa.selenium.By;
import org.openqa.selenium.support.Color;
import org.testng.asserts.SoftAssert;

import java.awt.*;

import static org.example.stepDefs.Hooks.driver;
public class D02_login {
    SoftAssert soft =new SoftAssert();
    P02_login Login =new P02_login();

    @When("user go to login page")
    public void Loginpage(){
        Login.LoginClick().click();
    }

    @And("user login with valid and password")
    public void userLoginWithValidAndPassword() {
        Login.ValidEmail().sendKeys("AyaTarek6@gmail.com");
        Login.ValidPassword().sendKeys("20111997");
    }

    @And("user press on login button")
    public void userPressOnLoginButton() {
        Login.Loginbutton().click();
    }

    @Then("user login to the system successfully")
    public void userLoginToTheSystemSuccessfully() {
        String URL=driver.getCurrentUrl();
        soft.assertEquals(URL,"https://demo.nopcommerce.com/");


        Boolean Button =driver.findElement(By.className("ico-account")).isDisplayed();
        soft.assertTrue(Button);


        soft.assertAll();



    }

    @And("user login with invalid and password")
    public void userLoginWithInvalidAndPassword() {
        Login.InvalidEmail().sendKeys("RanaSameh@gmail.com");
        Login.InvalidPassword().sendKeys("011726352");
    }

    @Then("user could not login to the system")
    public void userCouldNotLoginToTheSystem() {
        String ErrorMessage =driver.findElement(By.cssSelector("div[class=\"message-error validation-summary-errors\"]")).getText();
        soft.assertTrue(ErrorMessage.contains("Login was unsuccessful"));


        String ColorRed= Color.fromString
          (driver.findElement(By.cssSelector("div[class=\"message-error validation-summary-errors\"]")).getCssValue("color")).asHex();
          soft.assertEquals(ColorRed,"#e4434b");


          soft.assertAll();











    }
    }


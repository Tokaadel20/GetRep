package org.example.stepDefs;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.checkerframework.checker.units.qual.C;
import org.example.pages.P03_homePage;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

import static org.example.stepDefs.Hooks.driver;

public class D08_Wishlist {
    P03_homePage Home =new P03_homePage();
    SoftAssert soft =new SoftAssert();
    @When("User Select \"HTC One M8 Android L 5.0 Lollipop")
    public void SelectProduct(){
        Home.SelectProduct().get(2).click();
        Home.AddWishList().click();

        
    }

    @Then("the successfull msg appear")
    public void theSuccessfullMsgAppear() {
        Boolean Msg =Home.SuccessMsg().isDisplayed();
        Assert.assertTrue(Msg);

        String SuccessMsg=Home.SuccessMsg().getText();
        Assert.assertTrue(SuccessMsg.contains("The product has been added to your "));

        String Color= org.openqa.selenium.support.Color.fromString(Home.SuccessMsg().getCssValue("background-color")).asHex();
        Assert.assertEquals(Color,"#4bb07a");
        //System.out.println(Color);



    }

    @And("User clicks on wishlist button")
    public void userClicksOnWishlistButton() {
        WebDriverWait Explicit=new WebDriverWait(driver,Duration.ofSeconds(7));
        Explicit.until(ExpectedConditions.invisibilityOf(Home.SuccessMsg()));
        Home.WishListButton().click();

    }

    @Then("User Check the quantity of the product")
    public void userCheckTheQuantityOfTheProduct() {
        String Qnatity=Home.WishListQunantity().getAttribute("value");
        soft.assertTrue(Integer.parseInt(Qnatity)>0 );
        soft.assertAll();

    }
}

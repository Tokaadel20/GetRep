package org.example.stepDefs;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.checkerframework.checker.units.qual.C;
import org.example.pages.P01_register;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

import static org.example.stepDefs.Hooks.driver;
public class D01_register {
    SoftAssert soft = new SoftAssert();
    P01_register Register = new P01_register();

    @When("user go to register page")
    public void Registerclick() {
        Register.Registerpage().click();
    }


    @And("user select gender type")
    public void userSelectGenderType() {
        Register.Gender().click();
    }

    @And("user enter first name and last name")
    public void userEnterFirstNameAndLastName() {
        Register.firstname().sendKeys("Toka");
        Register.Lastname().sendKeys("Adel");

    }

    @And("user enter date of birth")
    public void userEnterDateOfBirth() {
        Select Year=new Select(Register.Year());
          Year.selectByValue("1997");
        Select Month =new Select(Register.Month());
        Month.selectByVisibleText("October");
        Select Day=new Select(Register.Day());
        Day.selectByValue("30");

    }

    @And("user enter email field")
    public void userEnterEmailField() {
        Register.Email().sendKeys("AyaTarek6@gmail.com");

    }

    @And("user fills Password fields")
    public void userFillsPasswordFields() {
        Register.Password().sendKeys("20111997");
        Register.ConfirmPassword().sendKeys("20111997");
    }

    @And("user clicks on register button")
    public void userClicksOnRegisterButton() {
       Register.RegisterButton().click();
    }

    @Then("success message is displayed")
    public void successMessageIsDisplayed() {
        String Message=driver.findElement(By.cssSelector("div[class=\"result\"]")).getText();
        soft.assertEquals(Message,"Your registration completed");

        String Color=driver.findElement(By.cssSelector("div[class=\"result\"]")).getCssValue("color");
        soft.assertEquals(Color,"rgba(76, 177, 124, 1)");
        System.out.println(Color);

        String URL=driver.getCurrentUrl();
        soft.assertEquals(URL,"https://demo.nopcommerce.com/registerresult/1?returnUrl=/");

        soft.assertAll();




    }
}
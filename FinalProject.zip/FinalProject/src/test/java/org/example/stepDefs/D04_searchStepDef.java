package org.example.stepDefs;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_homePage;
import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import static org.example.stepDefs.Hooks.driver;

public class D04_searchStepDef {
    P03_homePage Home =new P03_homePage();
    SoftAssert soft =new SoftAssert();


    @When("User Enter  product name {string}")
    public void userEnterProductName(String arg0) {
        Home.Searchicon().sendKeys(arg0);
        Home.SearchClick().click();
    }




    @Then("products contain {string} appear in search list")
    public void productsContainAppearInSearchList(String arg0) {
        String Url= driver.getCurrentUrl();
        soft.assertTrue(Url.contains("\"https://demo.nopcommerce.com/search?q=\""));

        for (int S=0 ; S< Home.SearchResult().size(); S++){
                String ProductSearch=Home.SearchResult().get(S).getText().toLowerCase().trim();
                soft.assertTrue(ProductSearch.contains(arg0));
        }

    }
    ///Sku

    @When("User Enter product Sku {string}")
    public void userEnterProductSku(String arg0) {
        Home.Searchicon().sendKeys(arg0);
        Home.SearchClick().click();


    }

    @And("productss contain  {string} appear in search list")
    public void productssContainAppearInSearchList(String arg0) {
        String URL=driver.getCurrentUrl();
        soft.assertTrue(URL.contains("https://demo.nopcommerce.com/search?q="));

        soft.assertAll();
    }

    @Then("I verify the SKU shown on the product page")
    public void iVerifyTheSKUShownOnTheProductPage() {
        Home.Product1().click();
        String Product1=driver.findElement(By.id("sku-17")).getText();
        soft.assertTrue(Product1.contains("SKU:APPLE_CAM"));

        Home.Product2().click();
        String Product2=driver.findElement(By.id("sku-36")).getText();
        soft.assertTrue(Product2.contains("SKU: SCI_FAITH"));

        Home.Product3().click();
        String Product3=driver.findElement(By.id("sku-12")).getText();
        soft.assertTrue(Product3.contains("SKU:SF_PRO_11"));


    }
}
package org.example.stepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_homePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

import static org.example.stepDefs.Hooks.driver;

public class D05_hoverCategories {
    P03_homePage Home =new P03_homePage();
    SoftAssert soft =new SoftAssert();
   // List<WebElement> SubCategories = new ArrayList<>();
    @When("User select random one of the three main categories")
    public void MainCategory(){
        List<WebElement> Categories =new ArrayList<>();
        Categories.add(Home.Computers());
        Categories.add(Home.Electronics());
        Categories.add(Home.Apparel());
        int min = 0;
        int max = Categories.size()-1;
        int random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
        Actions action=new Actions(driver);
        action.moveToElement(Categories.get(random_int)).perform();

         Actions actions=new Actions(driver);
         actions.moveToElement(Categories.get(0)).perform();




    }

    @And("User select random one of the three sub categries")
    public void userSelectRandomOneOfTheThreeSubCategries() {
       List<WebElement> SubCategory=new ArrayList<>();
     SubCategory.add(Home.Destop());
     SubCategory.add(Home.Notebooks());
     SubCategory.add(Home.Software());

        int min = 0;
        int max = SubCategory.size()-1;
        int randoms_int = (int)Math.floor(Math.random() * (max - min + 1) +min);
        Actions actions=new Actions(driver);
         actions.moveToElement(SubCategory.get(0)).perform();




    }




    @Then("User should go to sub category page")
    public void userShouldGoToSubCategoryPage() {
        Home.PageTitle().click();
        String PageTitle=driver.findElement(By.cssSelector("\"div[class=\\\"page-title\\\"]>h1\")")).getText().toLowerCase().trim();
        soft.assertTrue(PageTitle.contains("Desktops"));
        soft.assertAll();
    }


}

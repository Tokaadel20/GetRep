package org.example.stepDefs;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_homePage;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.ArrayList;

import static org.example.stepDefs.Hooks.driver;

public class D07_followUs {
    P03_homePage Home = new P03_homePage();
    SoftAssert soft = new SoftAssert();
@When("User clicks on Facebook Icon")
    public void FaceBookClick() {
    Home.FacebookIcon().click();

}

    @Then("User go to Facebook page")
    public void userGoToFacebookPage() {
        WebDriverWait Explicit= new WebDriverWait(driver,Duration.ofSeconds(10));
        Explicit.until(ExpectedConditions.numberOfWindowsToBe(2));

        ArrayList<String> Tabs = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(Tabs.get(1));

        String URL =driver.getCurrentUrl();
        soft.assertEquals(URL,"https://www.facebook.com/nopCommerce");
        soft.assertAll();
    }

    @When("User clicks on Twitter Icon")
    public void userClicksOnTwitterIcon() {
        Home.TwitterIcon().click();
    }

    @Then("User go to Twitter page")
    public void userGoToTwitterPage() {

        WebDriverWait Explicit= new WebDriverWait(driver,Duration.ofSeconds(10));
        Explicit.until(ExpectedConditions.numberOfWindowsToBe(2));

        ArrayList<String> Tabs = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(Tabs.get(1));

        String URL =driver.getCurrentUrl();
        soft.assertEquals(URL,"https://twitter.com/nopCommerce");
        soft.assertAll();
    }

    @When("User clicks on RSS Icon")
    public void userClicksOnRSSIcon() {
    Home.RSSIcon().click();
    }


    @Then("User go to RSS page")
    public void userGoToRSSPage() {
        WebDriverWait Explicit = new WebDriverWait(driver, Duration.ofSeconds(7));
        Explicit.until(ExpectedConditions.numberOfWindowsToBe(2));

        ArrayList<String> Tabs = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(Tabs.get(1));

        String URL =driver.getCurrentUrl();
        soft.assertEquals(URL,"https://demo.nopcommerce.com/new-online-store-is-open");
        soft.assertAll();

    }

    @When("User clicks on Youtube icon")
    public void userClicksOnYoutubeCon() {
    Home.YoutubeIcon().click();

    }

    @Then("User go to Youtube page")
    public void userGoToYoutubePage() {
        WebDriverWait Explicit = new WebDriverWait(driver, Duration.ofSeconds(7));
        Explicit.until(ExpectedConditions.numberOfWindowsToBe(2));

        ArrayList<String> Tabs = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(Tabs.get(1));

        String URL =driver.getCurrentUrl();
        soft.assertEquals(URL, "https://www.youtube.com/user/nopCommerce");
        soft.assertAll();
    }
}
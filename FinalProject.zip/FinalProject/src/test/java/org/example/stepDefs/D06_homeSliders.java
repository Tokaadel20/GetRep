package org.example.stepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_homePage;
import org.testng.asserts.SoftAssert;
import static org.example.stepDefs.Hooks.driver;

public class D06_homeSliders {
    P03_homePage Home =new P03_homePage();
    SoftAssert soft =new SoftAssert();
    @When("User choose First Slider in home page")
public void FirstSlider(){
        Home.SlideClick().get(0).click();

    }

    @And("User clicks on first slider")
    public void userClicksOnFirstSlider() {
        Home.Slider().get(0).click();
    }

    @Then("User should direct into First product link")
    public void userShouldDirectIntoFirstProductLink() {
String URL=driver.getCurrentUrl();
soft.assertEquals(URL,"https://demo.nopcommerce.com/nokia-lumia-1020");
soft.assertAll();
    }



    @When("User choose on Second Slider in home page")
    public void userChooseOnSecondSliderInHomePage() {
        Home.SlideClick().get(1).click();
    }

    @And("User click on Second selected slider")
    public void userClickOnSecondSelectedSlider() {
        Home.Slider().get(1).click();
    }

    @Then("User should direct into Second product link")
    public void userShouldDirectIntoSecondProductLink() {
        String Url=driver.getCurrentUrl();
        soft.assertEquals(Url,"https://demo.nopcommerce.com/iphone-6");
        soft.assertAll();    }
}

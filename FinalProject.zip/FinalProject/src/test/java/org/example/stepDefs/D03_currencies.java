package org.example.stepDefs;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_homePage;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

import static org.example.stepDefs.Hooks.driver;
public class D03_currencies {
P03_homePage Home =new P03_homePage();
SoftAssert soft =new SoftAssert();

@When("User select currency from list")
    public void SelectEuro(){
    Select Currency = new Select(Home.Currency());
    Currency.selectByVisibleText("Euro");



}

    @Then("The products Show in home page with Euro price")
    public void theProductsShowInHomePageWithEuroPrice() {
    for (int i=0; i<4;  i++){
        String Productprice=Home.PriceList().get(i).getText();
        soft.assertTrue(Productprice.contains("€"));
        soft.assertAll();
    }

    }
}

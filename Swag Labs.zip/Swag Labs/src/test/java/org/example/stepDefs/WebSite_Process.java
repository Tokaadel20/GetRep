package org.example.stepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.HomePage;
import org.openqa.selenium.By;
import org.testng.Assert;

import static org.example.stepDefs.Hooks.driver;

public class WebSite_Process {
    HomePage log =new HomePage();
    @When("User enter valid name & valid password")
    public void Login(){
log.Username().sendKeys("standard_user");
log.Password().sendKeys("secret_sauce");
log.Loginicon().click();
String Word=driver.findElement(By.cssSelector("span[class=\"title\"]")).getText();
Assert.assertEquals(Word,"Products");


    }

    @And("go to home page add product to the cart")
    public void goToHomePageAddProductToTheCart() {
        log.AddProduct().get(0).click();
        log.AddProduct().get(1).click();
        log.AddProduct().get(2).click();
    }

    @Then("go to checkout page and confirmation order")
    public void goToCheckoutPageAndConfirmationOrder() {
        log.Mycart().click();
        String Cart=driver.findElement(By.cssSelector("span[class=\"title\"]")).getText();
        Assert.assertEquals(Cart,"Your Cart");
        log.Checkout().click();
        log.firstname().sendKeys("Toka");
        log.Lastname().sendKeys("Adel");
        log.PostalCode().sendKeys("Zayed");
        log.contiIcon().click();
        String Total=driver.findElement(By.cssSelector("div[class=\"summary_subtotal_label\"]")).getText();
        Assert.assertEquals(Total,"Item total: $53.97");

        log.Finish().click();
      String SucceffulMsg=driver.findElement(By.cssSelector("h2[class=\"complete-header\"]")).getText();
      Assert.assertEquals(SucceffulMsg,"Thank you for your order!");





    }

    @When("User enter invalid name & valid password")
    public void userEnterInvalidNameValidPassword() {
        log.Username().sendKeys("TokaAdel");
        log.Password().sendKeys("secret_sauce");
        log.Loginicon().click();





    }

    @And("user could not login to the system")
    public void userCouldNotLoginToTheSystem() {
        String ErrorMsg=driver.findElement(By.cssSelector("div[class=\"error-message-container error\"]")).getCssValue("background-color");
        Assert.assertEquals(ErrorMsg,"rgba(226, 35, 26, 1)");
        //System.out.println(ErrorMsg);
        String ErrorMsge=driver.findElement(By.cssSelector("div[class=\"error-message-container error\"]")).getText();
        Assert.assertEquals(ErrorMsge,"Epic sadface: Username and password do not match any user in this service");
    }

    @When("User enter valid name valid password")
    public void userEnterValidNameValidPassword() {
        log.Username().sendKeys("problem_user");
        log.Password().sendKeys("secret_sauce");
        log.Loginicon().click();

    }

    @And("go to home page addproduct to the cart")
    public void goToHomePageAddproductToTheCart() {
        log.ProductIcon().click();

    }

    @Then("go to checkout page andconfirmation order")
    public void goToCheckoutPageAndconfirmationOrder() {
        log.Mycart().click();
        String Cart=driver.findElement(By.cssSelector("span[class=\"title\"]")).getText();
        Assert.assertEquals(Cart,"Your Cart");
        log.Checkout().click();
        log.firstname().sendKeys("Toka");
        log.Lastname().sendKeys("Adel");
        log.PostalCode().sendKeys("Zayed");
        log.contiIcon().click();

        String Msg =driver.findElement(By.cssSelector("div[class=\"error-message-container error\"]")).getText();
        Assert.assertEquals(Msg,"Error: Last Name is required");

        String Msgg=driver.findElement(By.cssSelector("div[class=\"error-message-container error\"]")).getCssValue("background-color");
        Assert.assertEquals(Msgg,"rgba(226, 35, 26, 1)");
        System.out.println(Msgg);


    }
}

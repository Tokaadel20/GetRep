package org.example.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

import static org.example.stepDefs.Hooks.driver;
public class HomePage {
    public WebElement Username(){
        return driver.findElement(By.id("user-name"));
    }
    public WebElement Password(){
        return driver.findElement(By.id("password"));
    }
public WebElement Loginicon(){
        return driver.findElement(By.cssSelector("input[class=\"submit-button btn_action\"]"));
}
public List<WebElement> AddProduct(){
        return driver.findElements(By.cssSelector("button[class=\"btn btn_primary btn_small btn_inventory \"]"));
}
public WebElement Mycart(){
        return driver.findElement(By.cssSelector("a[class=\"shopping_cart_link\"]"));
}
public WebElement Checkout(){
        return driver.findElement(By.id("checkout"));
}
public WebElement firstname(){
        return driver.findElement(By.name("firstName"));

}
public WebElement Lastname(){
    return driver.findElement(By.name("lastName"));
}
public WebElement PostalCode(){
    return driver.findElement(By.name("postalCode"));

}
public WebElement contiIcon(){
    return driver.findElement(By.name("continue"));

}
public WebElement Finish(){
        return driver.findElement(By.id("finish"));
}

public WebElement ProductIcon(){
        return driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-fleece-jacket\"]"));
}



    
}
